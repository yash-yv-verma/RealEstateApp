package edu.utsa.cs3443.xmf194_lab3.model;

import android.content.res.AssetManager;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The class representing a Listing, which contains a list of properties.
 */
public class Listing extends Property {
    private ArrayList<Property> properties;

    /**
     * Constructor to create a Listing object.
     *
     * @param id       The unique identifier for the property.
     * @param location The location of the property.
     * @param price    The price of the property.
     */

    public Listing(String id, String location, String price) {

        super(id, location, price);
        this.properties = new ArrayList<Property>();

    }

    /**
     * Load properties from a CSV file and add them to the listing.
     *
     * @param manager The AssetManager to access the CSV file.
     * @throws IOException If there is an error reading the CSV file.
     */
    public void loadProperties(AssetManager manager) throws IOException {

        InputStream inputStream = manager.open("listings.csv");
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        String line;

        // Loop through each line in the CSV file.
        while ((line = bufferedReader.readLine()) != null) {

            String[] tokens = line.split(",");
            // Create a Character object for each line of data

            if ((tokens[0].substring(0, 2)).equals("cp")) {
                Property property = new CommercialProperty(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]);
                this.properties.add(property);
            } else if ((tokens[0].substring(0, 2)).equals("rp")) {
                Property property = new ResidentialProperty(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]);
                this.properties.add(property);
            } else {
                System.out.println("APP NOT WORKING!");
            }

        }

        // Close the file and input streams.
        bufferedReader.close();
        inputStreamReader.close();
        inputStream.close();

        // Closes the file
        //scan.close();
    }

    /**
     * Get a property by its address.
     *
     * @param propertyAddress The address of the property to retrieve.
     * @return The Property object with the specified address, or null if not found.
     */
    public Property getProperty(String propertyAddress) {
        for (int i = 0; i < properties.size(); i++) {
            if (properties.get(i).getLocation().equals(propertyAddress)) {
                Property retProp = properties.get(i);
                return retProp;
            }
        }
        return null;
    }

    /**
     * Get the list of properties in the listing.
     *
     * @return The list of properties.
     */
    public ArrayList<Property> getProperties() {
        return properties;
    }

    /**
     * Set the list of properties in the listing.
     *
     * @param properties The list of properties to set.
     */
    public void setProperties(ArrayList<Property> properties) {
        this.properties = properties;
    }

    /**
     * Generate a string representation of the Listing object.
     *
     * @return A string representation containing the list of properties.
     */
    public String toString() {
        return "Listing{" + "properties=" + properties + '}';
    }
}