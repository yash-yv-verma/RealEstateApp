package edu.utsa.cs3443.xmf194_lab3.model;

/**
 * The class representing a Residential Property, which is a type of Property.
 */
public class ResidentialProperty extends Property {

    private String annHOAFee;// Annual HOA (Homeowners Association) fee for the residential property.
    private String numOfBedrooms;// Number of bedrooms in the residential property.
    private String numOfBathrooms;// Number of bathrooms in the residential property.

    /**
     * Constructor to initialize a ResidentialProperty object.
     *
     * @param id             The unique identifier for the property.
     * @param location       The location of the property.
     * @param price          The price of the property.
     * @param annHOAFee      The annual HOA fee of the residential property.
     * @param numOfBathrooms The number of bathrooms in the residential property.
     * @param numOfBedrooms  The number of bedrooms in the residential property.
     */
    public ResidentialProperty(String id, String location, String price, String annHOAFee, String numOfBathrooms, String numOfBedrooms) {

        super(id, location, price);
        this.annHOAFee = annHOAFee;
        this.numOfBathrooms = numOfBathrooms;
        this.numOfBedrooms = numOfBedrooms;

    }

    /**
     * Get the annual HOA fee of the residential property.
     *
     * @return The annual HOA fee.
     */
    public String getAnnHOAFee() {
        return annHOAFee;
    }

    /**
     * Set the annual HOA fee of the residential property.
     *
     * @param annHOAFee The annual HOA fee to set.
     */

    public void setAnnHOAFee(String annHOAFee) {
        this.annHOAFee = annHOAFee;
    }

    /**
     * Get the number of bedrooms in the residential property.
     *
     * @return The number of bedrooms.
     */

    public String getNumOfBedrooms() {
        return numOfBedrooms;
    }

    /**
     * Set the number of bedrooms in the residential property.
     *
     * @param numOfBedrooms The number of bedrooms to set.
     */
    public void setNumOfBedrooms(String numOfBedrooms) {
        this.numOfBedrooms = numOfBedrooms;
    }

    /**
     * Get the number of bathrooms in the residential property.
     *
     * @return The number of bathrooms.
     */
    public String getNumOfBathrooms() {
        return numOfBathrooms;
    }

    /**
     * Set the number of bathrooms in the residential property.
     *
     * @param numOfBathrooms The number of bathrooms to set.
     */
    public void setNumOfBathrooms(String numOfBathrooms) {
        this.numOfBathrooms = numOfBathrooms;
    }

    /**
     * Generate a string representation of the ResidentialProperty object.
     *
     * @return A string representation containing annual HOA fee, number of bedrooms, and number of bathrooms.
     */
    public String toString() {
        return "ResidentialProperty{" + "annHOAFee='" + annHOAFee + '\'' + ", numOfBedrooms='" + numOfBedrooms + '\'' + ", numOfBathrooms='" + numOfBathrooms + '\'' + '}';
    }
}