package edu.utsa.cs3443.xmf194_lab3.model;

/**
 * The class representing a Commercial Property, which is a type of Property.
 */
public class CommercialProperty extends Property {

    private String zone;// Zoning information for the commercial property.
    private String numOfUnits;// Number of units in the commercial property.
    private String numOfParking;// Number of parking spaces available for the commercial property.

    /**
     * Constructor to initialize a CommercialProperty object.
     *
     * @param id           The unique identifier for the property.
     * @param location     The location of the property.
     * @param price        The price of the property.
     * @param zone         The zoning information for the commercial property.
     * @param numOfUnits   The number of units in the commercial property.
     * @param numOfParking The number of parking spaces available for the commercial property.
     */
    public CommercialProperty(String id, String location, String price, String zone, String numOfUnits, String numOfParking) {

        super(id, location, price);
        this.zone = zone;
        this.numOfUnits = numOfUnits;
        this.numOfParking = numOfParking;

    }

    /**
     * Get the zoning information for the commercial property.
     *
     * @return The zoning information.
     */
    public String getZone() {
        return zone;
    }

    /**
     * Set the zoning information for the commercial property.
     *
     * @param zone The zoning information to set.
     */
    public void setZone(String zone) {
        this.zone = zone;
    }

    /**
     * Get the number of units in the commercial property.
     *
     * @return The number of units.
     */

    public String getNumOfUnits() {
        return numOfUnits;
    }

    /**
     * Set the number of units in the commercial property.
     *
     * @param numOfUnits The number of units to set.
     */
    public void setNumOfUnits(String numOfUnits) {
        this.numOfUnits = numOfUnits;
    }

    /**
     * Get the number of parking spaces available for the commercial property.
     *
     * @return The number of parking spaces.
     */
    public String getNumOfParking() {
        return numOfParking;
    }

    /**
     * Set the number of parking spaces available for the commercial property.
     *
     * @param numOfParking The number of parking spaces to set.
     */
    public void setNumOfParking(String numOfParking) {
        this.numOfParking = numOfParking;
    }

    /**
     * Generate a string representation of the CommercialProperty object.
     *
     * @return A string representation containing zoning information, number of units, and number of parking spaces.
     */
    public String toString() {
        return "CommercialProperty{" + "zone='" + zone + '\'' + ", numOfUnits='" + numOfUnits + '\'' + ", numOfParking='" + numOfParking + '\'' + '}';
    }
}