package edu.utsa.cs3443.xmf194_lab3.controller;

import android.content.res.AssetManager;
import android.view.View;
import android.widget.Toast;

import java.io.IOException;

import edu.utsa.cs3443.xmf194_lab3.MainActivity;
import edu.utsa.cs3443.xmf194_lab3.R;
import edu.utsa.cs3443.xmf194_lab3.model.*;

/**
 * The controller class responsible for handling property-related actions.
 */
public class PropertyController implements View.OnClickListener {
    MainActivity mainActivity;
    AssetManager manager;

    /**
     * Constructor to create a PropertyController instance.
     *
     * @param mainActivity The MainActivity that uses this controller.
     */
    public PropertyController(MainActivity mainActivity) {
        mainActivity = mainActivity;
        manager = mainActivity.getAssets();

    }

    /**
     * Handle button click events.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {

        Listing l = new Listing("ok", "ko", "lo");

        try {
            l.loadProperties(manager);
        } catch (IOException e) {
            e.printStackTrace();
        }


        // Code here will execute when a button is clicked.
        int idOfButtonPressed = v.getId();

        //Toast for the buttons respectively.
        if (idOfButtonPressed == R.id.button1) {
            Toast.makeText(v.getContext(), l.getProperties().get(0).getPrice(), Toast.LENGTH_LONG).show();
        } else if (idOfButtonPressed == R.id.button2) {
            Toast.makeText(v.getContext(), l.getProperties().get(1).getPrice(), Toast.LENGTH_LONG).show();
        } else if (idOfButtonPressed == R.id.button3) {
            Toast.makeText(v.getContext(), l.getProperties().get(2).getPrice(), Toast.LENGTH_LONG).show();
        } else if (idOfButtonPressed == R.id.button4) {
            Toast.makeText(v.getContext(), l.getProperties().get(3).getPrice(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(v.getContext(), "Something strange happened!", Toast.LENGTH_LONG).show();
        }
    }
}

