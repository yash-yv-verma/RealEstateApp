package edu.utsa.cs3443.xmf194_lab3.model;

/**
 * The abstract class representing a Property.
 */
public abstract class Property {

    private String id;// Unique identifier for the property.
    private String location;// Location of the property.
    private String price;// Price of the property.

    /**
     * Constructor to initialize a Property object.
     *
     * @param id       The unique identifier for the property.
     * @param location The location of the property.
     * @param price    The price of the property.
     */
    public Property(String id, String location, String price) {

        this.id = id;
        this.location = location;
        this.price = price;

    }

    /**
     * Get the unique identifier of the property.
     *
     * @return The unique identifier.
     */
    public String getId() {
        return id;
    }

    /**
     * Set the unique identifier of the property.
     *
     * @param id The unique identifier to set.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Get the location of the property.
     *
     * @return The location.
     */
    public String getLocation() {
        return location;
    }

    /**
     * Set the location of the property.
     *
     * @param location The location to set.
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Get the price of the property.
     *
     * @return The price.
     */
    public String getPrice() {
        return price;
    }

    /**
     * Set the price of the property.
     *
     * @param price The price to set.
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * Generate a string representation of the Property object.
     *
     * @return A string representation containing id, location, and price.
     */
    public String toString() {
        return "Property{" + "id='" + id + '\'' + ", location='" + location + '\'' + ", price='" + price + '\'' + '}';
    }
}