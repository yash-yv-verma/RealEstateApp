package edu.utsa.cs3443.xmf194_lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import edu.utsa.cs3443.xmf194_lab3.controller.PropertyController;
import edu.utsa.cs3443.xmf194_lab3.model.*;
import edu.utsa.cs3443.xmf194_lab3.*;

/**
 * MainActivity is the main entry point of the application.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Create a PropertyController instance to manage property-related actions.
        PropertyController controller = new PropertyController(this);

        // Get references to buttons in the layout and set their click listeners to the controller.
        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(controller);

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(controller);

        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(controller);

        Button button4 = findViewById(R.id.button4);
        button4.setOnClickListener(controller);
    }
}